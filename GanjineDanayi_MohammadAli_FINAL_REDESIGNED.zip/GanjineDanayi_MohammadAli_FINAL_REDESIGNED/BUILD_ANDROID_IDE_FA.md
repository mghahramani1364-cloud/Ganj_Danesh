راهنمای سریع AndroidIDE

۱) ZIP را استخراج کن.
۲) در AndroidIDE پوشهٔ ریشه را باز کن؛ باید settings.gradle و app/ را ببینی.
۳) اجازه بده Gradle Sync کامل شود.
۴) از منوی Build، Build APK / Assemble Debug را اجرا کن.
۵) فایل app/build/outputs/apk/debug/app-debug.apk ساخته می‌شود.

تنظیم پروژه: AGP 8.6.1، Gradle 8.7، compileSdk 35، minSdk 23.
این بسته فایل‌های منبع و بانک سؤال را دارد؛ APK آماده داخل ZIP نیست.

Gradle: Android Gradle Plugin 8.6.1 و Gradle 8.7. فایل‌های build.gradle واقعی در ریشه و app موجودند. فایل gradlew از توزیع Gradle 8.7 استفاده می‌کند؛ دریافت توزیع فقط در صورت نبودن نسخهٔ ذخیره‌شده نیازمند اینترنت است.
